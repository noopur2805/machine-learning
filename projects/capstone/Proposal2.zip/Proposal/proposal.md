# Machine Learning Engineer Nanodegree
## Capstone Proposal
Noopur Koshta  
April 21st, 2018

## Proposal
**Predicting Wine Quality**

### Domain Background

The main purpose of this study is to predict wine quality based on physicochemical data. In this study, two large separate data sets which were taken from UCI Machine Learning Repository were used. These data sets contain 1599 instances for red wine and 4898 instances for  white wine  with 11  features of physicochemical data such as alcohol, chlorides, density, total sulfur dioxide, free sulfur dioxide, residual sugar, and pH. The composition of wines altogether decide the quality of wine. The wine  quality being graded between 0 (very bad) and 10 (very excellent). The two datasets are related to red and white variants of the Portuguese “Vinho Verde” wine.

With time, the composition of wine changes, and thus it is important to keep the preservation methods of the wine in check to maintain the qualilty of wine as far as possible. Each substance has a role to play in maintaining taste as wellas quality of wine, in terms of color, taste, pH (acidity), sweetness, etc.

Wine is one of the popular and most loved beverages around the world. And it comes with health benefits too, such as it lowers risk of heart disease, reduces risk of type-2 diabetes, cuts risk of cataract, cuts risk of colon cancer, slows brain decline, increases bone density.

In this section, provide brief details on the background information of the domain from which the project is proposed. Historical information relevant to the project should be included. It should be clear how or why a problem in the domain can or should be solved. Related academic research should be appropriately cited in this section, including why that research is relevant. Additionally, a discussion of your personal motivation for investigating a particular problem in the domain is encouraged but not required.

### Problem Statement

To ensure the quality of wine is maintained, the wine composition has to meet the standards defined for a good quality wine (both red and whie wines). So, the acidity interms of proportion of volatile and non-volatile acids, sulphates and chlorides, has to be in proportion too to avoid oxidation of wine. Since with time these factors may degrade, thus in what proportions can sulphates, or free SO2 can be injected so as to prevent microbes to further oxidize or to say degrade the wine, thus causing degradation in taste of wine too.

### Datasets and Inputs

Number of Instances: red wine - 1599; white wine - 4898.
Number of Attributes: 11 + output attribute

The two datasets are related to red and white variants of the Portuguese "Vinho Verde" wine. For more details, consult: http://www.vinhoverde.pt/en/ or the reference [Cortez et al., 2009](http://www3.dsi.uminho.pt/pcortez/wine5.pdf).

**Input variables (based on physicochemical tests):**
1 - fixed acidity (tartaric acid - g / dm^3) 
2 - volatile acidity (acetic acid - g / dm^3) 
3 - citric acid (g / dm^3) 
4 - residual sugar (g / dm^3) 
5 - chlorides (sodium chloride - g / dm^3 
6 - free sulfur dioxide (mg / dm^3) 
7 - total sulfur dioxide (mg / dm^3) 
8 - density (g / cm^3) 
9 - pH 
10 - sulphates (potassium sulphate - g / dm3) 
11 - alcohol (% by volume) 

**Output variable (based on sensory data):**
12 - quality (score between 0 and 10)

**Description of attributes:**

1 - fixed acidity: most acids involved with wine or fixed or nonvolatile (do not evaporate readily)
2 - volatile acidity: the amount of acetic acid in wine, which at too high of levels can lead to an unpleasant, vinegar taste
3 - citric acid: found in small quantities, citric acid can add 'freshness' and flavor to wines
4 - residual sugar: the amount of sugar remaining after fermentation stops, it's rare to find wines with less than 1 gram/liter and wines with greater than 45 grams/liter are considered sweet
5 - chlorides: the amount of salt in the wine
6 - free sulfur dioxide: the free form of SO2 exists in equilibrium between molecular SO2 (as a dissolved gas) and bisulfite ion; it prevents microbial growth and the oxidation of wine
7 - total sulfur dioxide: amount of free and bound forms of S02; in low concentrations, SO2 is mostly undetectable in wine, but at free SO2 concentrations over 50 ppm, SO2 becomes evident in the nose and taste of wine
8 - density: the density of water is close to that of water depending on the percent alcohol and sugar content
9 - pH: describes how acidic or basic a wine is on a scale from 0 (very acidic) to 14 (very basic); most wines are between 3-4 on the pH scale
10 - sulphates: a wine additive which can contribute to sulfur dioxide gas (S02) levels, wich acts as an antimicrobial and antioxidant
11 - alcohol: the percent alcohol content of the wine

### Solution Statement

The solution for maintaining the quality of wine is foremost the temperature of storage. Warmer climate can disrupt the wine composition (mainly acidity and therfore the pH). Wine experts suggest that the ideal temperature range is between 45° F and 65° F, with 55° F often cited as close to perfect. Also, the free SO2 ingestion upto an extent defined under the safe limits can be done to prevent wines from getting oxidized. This will prevent microbes to oxidize the wine and thus this will maintain the pH levels in the wine too. Thus, we'll analyse all the features of tyhe wine to decide the quality of wine on the scale of 1-10 (10 classes).

### Benchmark Model

As cited in [The Classification of White Wine and Red Wine According to Their Physicochemical Qualities](https://www.researchgate.net/publication/311919082_The_Classification_of_White_Wine_and_Red_Wine_According_to_Their_Physicochemical_Qualities):

Results from  the experiments showed that Random Forests  Algorithm  performs  better  in  classification  task  as compared  against  the  support  vector  machine,  and  k-nearest neighbourhood.  

After applying PCA, the success rate of quality classification for white wine has decreased from 70.3757% to 69.9061% for cross validation  mode.  The  success  rate of  quality  classification  for white  wine  has  decreased  from  68.6735%  to  67.449%  for percentage split mode. 

After applying PCA, the success rate of quality classification for red  wine  has  increased  from  69.606%  to  71.232%  for  cross validation mode. The success rate of quality classification for red wine  samples  has  increased  from  71.875%  to  73.4375%  for percentage split mode. 

### Evaluation Metrics

Being a classification problem, wine quality can be evaluated using accuracy score of F-score metric, which will tell us how our classifiers performed in terms of:
1. Precision: (also called positive predictive value) is the fraction of relevant instances among the retrieved instances.
2. Recall: (also known as sensitivity) is the fraction of relevant instances that have been retrieved over the total amount of relevant instances.
3. F-score: is the harmonic mean of the precision and recall.

### Project Design

To start with, I'll find the correlation between the features of the wine dataset. This will lead to better understanding of how the quality of wine is highly dependent on which features. Though there is an idea from the research that pH ranging between 3-4 is usually observed as the most ideal for both white and red wines. This we'll further explore in the dataset if it's true. To maintain such a pH level the acidity content annd SO2 content have to be balanced. Also the residual sugars in the wine play quite a role in ablancing the acidity of wine and also contribute in the density factor of wines.

**Balancing the dataset:**
Before applying any machine learning model, we'll look into balancing our dataset first, ie. if the dataset is skewed then we'll first need to bring the dataset to a normal distribution, from which we can sample our data to train, cross-validate and test the results. For this I've decided to use SMOTEENN to balance out the dataset into each of the wine qualities. But wine qualities being on a scale of 1-10 seems to create a larger dataset while balancing, thus after applying this algorithm, I'll check if this trying to create quite larger dataset, to say, large number of false data points, then we'll introduce one more feature as wine quality ie. buckets of Excellent, Good, Average and Bad quality wines. These 4 classes might ease things out while balancing the dataset.

**Dimensionality Reduction:**
Then, PCA will be applied to the dataset to reduce the dimensionaliity of the data, before modelling.

**Modelling:**
Main algorithms considered for analysis of wine dataset are:

1. Support Vector Machine: This algorithm is great when dataset is not very large and when the dataset is cleaner, as is in our case.
2. Decision Tree and Random Forest: This algorithm wll help us to better understand which features are more relevant in deciding the quality of wine.
3. Ensemble Learning: The ensemble learning algorithms like Adaboost will enhance the performance of the classifier by boosting the weak classifiers performance by taking all of them into consideration to design a strong classifier. As our dataset does not have wide number of features thus this is great to work on since this algorithm works good with less complex models.
4. Logistic Regression: This algorithm being the most basic and simple seems to be traditional to use.

**Evaluating the model:**
In the end, evaluation metric obtained from the confusion metric will be used to evaluate how our models performed, and to analyse which model can best predct the wine quality with this dataset.

### References:
- https://winemakermag.com/547-phiguring-out-ph
- https://www.wineperspective.com/wine-acidity/
- https://www.accuvin.com/wp-content/uploads/2015/04/How-SO2-and-pH-are-Linked.pdf
- http://waterhouse.ucdavis.edu/whats-in-wine
- https://winemakermag.com/501-measuring-residual-sugar-techniques
- https://www.winebusiness.com/tools/?go=winemaking.calc&sid=5
- http://wine.wsu.edu/2010/10/13/managing-high-acidity/
- http://winefolly.com/tutorial/wine-for-beginners-infographic/
