import numpy as np
import pandas as pd

from imblearn.combine import SMOTEENN
from imblearn.over_sampling import SMOTE

def quality_buckets(val):
    
    if val in [0, 1, 2, 3, 4]:
        return 'Worst'
    elif val in [5, 6]:
        return 'Average'
    elif val in [7, 8]:
        return 'Good'
    else:
        return 'Best'
    
def balance_dataset(data):
    
    X = data.loc[:, ~data.columns.isin(['quality bucket','quality'])]
    y = data.loc[:, 'quality']
    
    sme = SMOTEENN(smote=SMOTE(k_neighbors=4), random_state=42, n_neighbors=3)
    sme_fitted = sme.fit_sample(X, y)
    X = pd.DataFrame(sme_fitted[0], columns= data.columns[~data.columns.isin(['quality bucket','quality'])])
    y = pd.DataFrame(sme_fitted[1], columns= ['quality'])
    X['quality'] = y
    X['quality bucket'] = X['quality'].apply(lambda x: quality_buckets(x))

    return X