# Machine Learning Engineer Nanodegree
## Capstone Project
Noopur Koshta
December 31st, 2050

## I. Definition

### Project Overview

Wine is not just an alcoholic beverage, but a healthy drink too when consumed in moderation. To achieve the health benefits of wine, it should be of good quality. Wine is one of the popular and most loved beverages around the world. And it comes with health benefits too, such as it lowers risk of heart disease, reduces risk of type-2 diabetes, cuts risk of cataract, cuts risk of colon cancer, slows brain decline, increases bone density.

The main purpose of this study is to predict wine quality based on physicochemical data. In this study, two large separate data sets which were taken from UCI Machine Learning Repository were used. These data sets contain 1599 instances for red wine and 4898 instances for  white wine  with 11  features of physicochemical data such as alcohol, chlorides, density, total sulfur dioxide, free sulfur dioxide, residual sugar, and pH. The composition of wines altogether decide the quality of wine. The wine  quality is being graded between 0 (very bad) and 10 (very excellent). The two datasets are related to red and white variants of the Portuguese “Vinho Verde” wine.

With time, the composition of wine changes, and thus it is important to keep the preservation methods of the wine in check to maintain the qualilty of wine as far as possible. Each substance has a role to play in maintaining taste as well as quality of wine, in terms of color, taste, pH (acidity), sweetness, etc.


### Datasets and Inputs

Number of Instances: red wine - 1599; white wine - 4898.
Number of Attributes: 11 + output attribute

The two datasets are related to red and white variants of the Portuguese "Vinho Verde" wine. For more details, consult: http://www.vinhoverde.pt/en/ or the reference [Cortez et al., 2009](http://www3.dsi.uminho.pt/pcortez/wine5.pdf).

**Input variables (based on physicochemical tests):**
1 - fixed acidity (tartaric acid - g / dm^3) 
2 - volatile acidity (acetic acid - g / dm^3) 
3 - citric acid (g / dm^3) 
4 - residual sugar (g / dm^3) 
5 - chlorides (sodium chloride - g / dm^3 
6 - free sulfur dioxide (mg / dm^3) 
7 - total sulfur dioxide (mg / dm^3) 
8 - density (g / cm^3) 
9 - pH 
10 - sulphates (potassium sulphate - g / dm3) 
11 - alcohol (% by volume) 

Note: 1 g/dm^3 = 1 g/L

**Output variable (based on sensory data):**
12 - quality (score between 0 and 10)
13 - quality bucket (Worst [0-4], Average[5-6], Good[7-8], Best[9-10]) - This is the additional feature introduced for data analysis.

**Description of attributes:**

1 - fixed acidity: most acids involved with wine or fixed or nonvolatile (do not evaporate readily)
2 - volatile acidity: the amount of acetic acid in wine, which at too high of levels can lead to an unpleasant, vinegar taste
3 - citric acid: found in small quantities, citric acid can add 'freshness' and flavor to wines
4 - residual sugar: the amount of sugar remaining after fermentation stops, it's rare to find wines with less than 1 gram/liter and wines with greater than 45 grams/liter are considered sweet
5 - chlorides: the amount of salt in the wine
6 - free sulfur dioxide: the free form of SO2 exists in equilibrium between molecular SO2 (as a dissolved gas) and bisulfite ion; it prevents microbial growth and the oxidation of wine
7 - total sulfur dioxide: amount of free and bound forms of S02; in low concentrations, SO2 is mostly undetectable in wine, but at free SO2 concentrations over 50 ppm, SO2 becomes evident in the nose and taste of wine
8 - density: the density of water is close to that of water depending on the percent alcohol and sugar content
9 - pH: describes how acidic or basic a wine is on a scale from 0 (very acidic) to 14 (very basic); most wines are between 3-4 on the pH scale
10 - sulphates: a wine additive which can contribute to sulfur dioxide gas (S02) levels, which acts as an antimicrobial and antioxidant
11 - alcohol: the percent alcohol content of the wine

### Relationship between attributes

A **low-pH** wine will taste tart, owing to the higher acid concentration. Conversely, a **high-pH** wine will taste flat and lack freshness. A high-pH wine also will tend to oxidize at a higher rate and therefore will not age as well. It will be more prone to microbial spoilage, thus requiring more sulfite. High-pH white wines will tend to brown prematurely. In the case of red wines, color intensity decreases as the pH increases, causing the wine to change from a red to a brownish-red color.

**Free SO2** is what protects the wine against oxidation and microbial organisms that could spoil the wine, and its effectiveness is dependent on a wine’s pH. As pH increases, free SO2 loses effectiveness, and therefore we need to add more sulfite to protect the wine. **Total SO2**, ,on the other hand, is the total SO2, comprised of free SO2 and the fixed SO2, ie. the SO2 content that has been oxidised and is inactive in protecting wine from microbes reaction.

As a rule of thumb, we should target a free SO2 level of approximately [(pH-3.0)x100] mg/L for red wines; for white wines add 10 to this value. This calculation assumes that your wine has a pH above 3.0. If the wine’s pH is above the recommended range, we need to lower that pH down to within the range as the first course of action. Pick a pH correction method that achieves results quickly, such as adding tartaric acid. Re-measure the pH, and when it falls within the recommended range, measure the free SO2 concentration and adjust it according to the rule of thumb. **Tartaric acid** crystals area used at the rate of approximately 1 g/L (0.13 ounce/gallon) of wine to reduce the pH by 0.1 unit. But it is recommended to add this acid pre-fermentation. On the other hand, Acid reduction using potassium bicarbonate or other acid-reducing agents, such as ACIDEX®, can be used to raise the pH in wines. Potassium bicarbonate raises pH by reducing tartaric acidity and is therefore recommended for high-TA, low-pH wines. Dissolve **potassium bicarbonate** at the rate of 1 g/L of wine for each 0.1 unit increase in pH. 

The **chlorides** give saltiness in taste to the wines. The Brazilian law establishes the maximum concentration of chlorides in wine at 0.20 g/L, expressed in sodium chloride. Some Australian and Argentine wines present concentration of chlorides above this value. In Australia, the maximum level allowed is 1 g/L, expressed as sodium chloride.

Both tartaric and malic acids are nonvolatile which means that they do not evaporate or boil off when the wine is heated. This is to be distinguished from **volatile acidity (VA)** in wine that represents **acetic acid (vinegar)**. Acetic acid does boil off when heated, and high VA is undesirable in a wine. A VA of 0.03-0.06% is produced during fermentation and is considered a normal level. The **total acidity (TA)** of a wine is the overall acid content in the wine. A high TA is 1.0%. Most people would find this level of acidity too tart and too sour for consumption. A low TA, say 0.4%, results in flat tasting wine that is more susceptible to infection and spoilage by microorganisms. Most red table wines are about 0.6% total acid. White wines are usually a little higher.

Tartaric and malic acids are produced by the grape as it develops. In warm climates, these acids are lost through the biochemical process of respiration. Therefore, grapes grown in warmer climates have lower acidity than grapes grown in cooler climates. **Sugar** production is the complete opposite of acid production. Warmer climates result in high sugar and low acid whereas cooler climates result in low sugar and high acid. Sugar is an essential component in the production of wine. During alcoholic fermentation, yeast feeds on the sugar found in grape juice and converts it to ethyl alcohol, or ethanol, and carbon dioxide. The amount of sugar fermented determines the wine’s alcohol level and the amount of residual sugar left in the wine. Dry wines are typically in the 0.2–0.3% range, off-dry wines in the 1.0–5.0% range, and sweet dessert wines in the 5–15% range.

In order to ensure consistency of the produce, **alcohol** levels are typically restricted for Vinho Verde wines to no more than 11.5%; _Vinho Verde Alvarinho_ is an exception to this rule as the intention is to recognise this special grape and to allow a richer wine to be produced to bring out the full character of the grape.

So, now we have a basic understanding of role of each of the ingredients of the wine. Thus, we are ready to analyse and categorize the wine on the basis of their quality on the scale of 1-10 (10 classes for the classifier), 10 being the best quality and 1 being the worst quality of wines.

### Problem Statement

To ensure the quality of wine is maintained, the wine composition has to meet the standards defined for a good quality wine (both red and whie wines), to say, the ingredients should be within the standard range or safer range for consumption. So, the acidity in terms of proportion of volatile and non-volatile acids, sulphates and chlorides, has to be in proportion too, to avoid oxidation of wine. Since with time these factors may degrade, thus in what proportions can sulphates, or free SO2 can be injected so as to prevent microbes to further oxidize or to say degrade the wine, thus causing degradation in taste of wine too.

In the end of classification of wine in the quality buckets, we'll see what caused the bad quality wines to go in that category and how we can still play with its composition to meet the quality standards.

### Metrics

This is clearly a classification problem,l and to measure the accuracy of the model, we can do so using F-score metric. We'll look into the performance of the classifiers using confusion matrix, to ensure how well the classifiers were able to make predictions.

## II. Analysis

### Data Exploration

Below is the snapshot of red wine dataset:
![dataset snapshot](/Images/img1.png)

Similar to the red wine, is the white wine dataset, ie. with same feature set.

The dataset as can be seen is mostly numerical and has no missing values. Many wines, both red and white, are over-treated with SO2, ie. 90% of both red and white wines have free and ths total SO2 content over the average quantity. Wines must have been  over-treated with free SO2 in a few cases to subdue the microbes growth. And thus the residual sugar must have been added to supress the tangy taste caused by the free SO2 content. Also, the pH was somehow still maintained for the wines. On plotting the volatile acidity against the quality, it was seen that with increased amount of volatile acidity in low quality wines, free SO2 remained the same which is undesirable since the microbes growth will stimulate in such conditions. And thus the explanation for the respective quality of wines.

### Exploratory Visualization


Red Wine Correlation Matrix  |  White Wine Correlation Matrix 
:-------------------------:|:-------------------------:
![](/Images/fig.1.2.1.png)  |  ![](/Images/fig.1.2.2.png)

Observations from the correlation matrix of `red wine` attributes:
- pH is almost negatively correlated to every acid content, which was obvious.
- Major takeaway is quality seems to be highly related to and the volatile acid content and the amount of alcohol, former positively and latter negatively correlated.
- Sulphates are slightly responsible for quality assurance here, but they still are one of the most important to maintain quality of wines as per theory.

Observations from the correlation between `white wine` attributes:
- Clearly, the residual sugar is highlighted to have the highest correlation with density. This was hoped to seen in red wines too, but was not found.
- Also, total SO2 is also contribute largely in the density of wines.
- Because of these factors, it can be guessed that white wines are quite difficult to preserve, since they must be rotting and thus to save them high amount of SO2 was added and also then to balance the taste residual sugar must have been added.
- More the alcohol, less is the density. This is more clearly visible here than in red wines. Which confirms my intuition of alcohol being related to density. 
- Quality seems to be highly related to the alcohol content here too.

As discussed in the above section, on plotting free SO2 and residual sugar against quality, not much of the difference can be found out in low and high quality wines. But on plotting volatile acidity, it was found that as required, the free SO2 wasn't increased in accordance with the amount of volatile acidity as depicted below:

![Free SO2 vs Quality](/Images/fig.1.3.1.png)
![Volatile Acidity vs Quality](/Images/fig.1.3.2.png)

### Algorithms and Techniques

The dataset is highly unbalanced, in terms of less number of wines in the good quality wines. Thus, I'll employ the dataset balancing techniques and compare the results with the non-balanced dataset too.

**Balancing the dataset:**
Before applying any machine learning model, we'll look into balancing our dataset first, ie. if the dataset is skewed then we'll first need to bring the dataset to a normal distribution, from which we can sample our data to train, cross-validate and test the results. For this I've decided to use SMOTEENN to balance out the dataset into each of the wine qualities.

**Modelling:**
Main algorithms considered for analysis of wine dataset are:

1. `Support Vector Machine:` This algorithm is great when dataset is not very large and when the dataset is cleaner, as is in our case.
2. `Decision Tree and Random Forest:` This algorithm wll help us to better understand which features are more relevant in deciding the quality of wine.
3. `Ensemble Learning:` The ensemble learning algorithms like Adaboost will enhance the performance of the classifier by boosting the weak classifiers performance by taking all of them into consideration to design a strong classifier. As our dataset does not have wide number of features thus this is great to work on since this algorithm works good with less complex models.
4. `Logistic Regression:` This algorithm being the most basic and simple seems to be traditional to use.
5. `Voting Classifier:` This algorithm will take the the majority rule voting applied to the predicted class labels. If a list of weights is provided, the averaged raw probabilities will be used to determine the most confident class label.

### Benchmark

As cited in [The Classification of White Wine and Red Wine According to Their Physicochemical Qualities](https://www.researchgate.net/publication/311919082_The_Classification_of_White_Wine_and_Red_Wine_According_to_Their_Physicochemical_Qualities):

Results from  the experiments showed that Random Forests  Algorithm  performs  better  in  classification  task  as compared  against  the  support  vector  machine,  and  k-nearest neighbourhood.  

After applying PCA, the success rate of quality classification for white wine has decreased from 70.3757% to 69.9061% for cross validation  mode.  The  success  rate of  quality  classification  for white  wine  has  decreased  from  68.6735%  to  67.449%  for percentage split mode. 

After applying PCA, the success rate of quality classification for red  wine  has  increased  from  69.606%  to  71.232%  for  cross validation mode. The success rate of quality classification for red wine  samples  has  increased  from  71.875%  to  73.4375%  for percentage split mode.

## III. Methodology

### Data Preprocessing

The only data preprocessing required was balancing the dataset, since the high quality wines are less in number as compared to the low quality wines and thus SMOTENN, ie.over-sampling technique is being used to  balance the dataset. 

**SMOTENN** is the combination of SMOTE (Synthetic Minority Over-sampling Technique) and ENN (Extended Nearest Neighbours). The minority class is over-sampled by taking each minority class sample and introducing synthetic examples along the line segments joining any/all of the k minority class nearest neighbors. This is how the minority class gets populated to equate the population with majority class.

The idea is to create new minority examples by interpolating between existing ones. The process is basically as follows. Assume we have a set of majority and minority examples, as before:
[SMOTE](/Images/fig.3.1.1.png)

The SMOTE samples are linear combinations of two similar samples from the minority class (x and x R ) and are defined as:
`s=x+u*(x^R−x)`

### Implementation

As mentioned under the section `Algorithms and Techniques`, follwing algorithms are used:
1. Support Vector Machine
2. Decision Tree
3. Random Forest
4. AdaBoost
5. Logistic Regression

For all of these algolrithms, unbalanced as well as balanced dataset are given and the results obtained are compared using the metric: accuracy score, F1-score, precision and recall.

These metrics are calculated frmo the confusion matrix obtained as:
[Confusion matrix](/Images/fig.3.2.1.png)

In the confusion matrix:

**True Positives (TP)** - These are the correctly predicted positive values which means that the value of actual class is yes and the value of predicted class is also yes. 
**True Negatives (TN)** - These are the correctly predicted negative values which means that the value of actual class is no and value of predicted class is also no. 

False positives and false negatives, these values occur when your actual class contradicts with the predicted class.

**False Positives (FP)** – When actual class is no and predicted class is yes. 
**False Negatives (FN)** – When actual class is yes but predicted class in no. 

Now with these 4 parameters, we can calculate Accuracy, Precision, Recall and F1 score.

**Accuracy** - Accuracy is the most intuitive performance measure and it is simply a ratio of correctly predicted observation to the total observations. One may think that, if we have high accuracy then our model is best. Yes, accuracy is a great measure but only when you have symmetric datasets where values of false positive and false negatives are almost same. Therefore, you have to look at other parameters to evaluate the performance of your model. 

`Accuracy = TP+TN / TP+FP+FN+TN`

**Precision** - Precision is the ratio of correctly predicted positive observations to the total predicted positive observations. High precision relates to the low false positive rate.

`Precision = TP / TP+FP`

**Recall (Sensitivity)** - Recall is the ratio of correctly predicted positive observations to the all observations in actual class - yes. 

`Recall = TP / TP+FN`

**F1 score** - F1 Score is the weighted average of Precision and Recall. Therefore, this score takes both false positives and false negatives into account. Intuitively it is not as easy to understand as accuracy, but F1 is usually more useful than accuracy, especially if you have an uneven class distribution. Accuracy works best if false positives and false negatives have similar cost. If the cost of false positives and false negatives are very different, it’s better to look at both Precision and Recall. 

`F1 Score = 2 * (Recall * Precision) / (Recall + Precision)`

### Refinement

As discussed, the SMOTENN algorithm was employed to balance the dataset, after which the results obtained were evaluated across metric such as accuracy,  F1-score, precision and recall.

The unbalanced _red wine_ dataset gave following results:

|Algorithm|Accuracy|F1-score|Precision|Recall|
|--|--|--|--|
|SVM|62.857143|66.568039|76.270335|62.857143|
|Decision Tree|57.755102|57.434317|58.434252|57.755102|
|Random Forest|69.897959|70.685029|70.664371|69.897959|
|AdaBoost|60.510204|60.653209|60.512814|60.510204|
|Logistic Regression|60.510204|60.653209|60.512814|60.510204|
|Voting Classifier|62.8125|63.472058|61.629377|62.8125|

The balanced _red wine_ dataset gave following results:

|Algorithm|Accuracy|F1-score|Precision|Recall|
|--|--|--|--|
|SVM|97.056118|97.111906|97.024009|97.056118|
|Decision Tree|90.478381|90.523097|90.433191|90.478381|
|Random Forest|96.182153|96.260615|96.126605|96.182153|
|AdaBoost|91.950322|91.933518|92.009583|91.950322|
|Logistic Regression|91.950322|91.933518|92.009583|91.950322|
|Voting Classifier|94.939271|95.242695|94.748055|94.939271|

So, in both the cases, **SVM** gave the best results with the accuracy of _97.05%_ when the dataset was balanced.

The unbalanced _white wine_ dataset gave following results:

|Algorithm|Accuracy|F1-score|Precision|Recall|
|--|--|--|--|
|SVM|62.653061|66.383691|73.395949|62.653061|
|Decision Tree|54.081633|54.953258|52.431700|54.081633|
|Random Forest|67.653061|68.424999|67.977345|67.653061|
|AdaBoost|62.755102|62.727468|62.865225|62.755102|
|Logistic Regression|62.755102|62.727468|62.865225|62.755102|
|Voting Classifier|64.489796|64.993313|64.687147|64.489796|

The balanced _white wine_ dataset gave following results:

|Algorithm|Accuracy|F1-score|Precision|Recall|
|--|--|--|--|
|SVM|97.424103|97.481616|97.603206|97.424103|
|Decision Tree|91.582337|91.655765|91.488393|91.582337|
|Random Forest|96.504140|96.605685|96.464859|96.504140|
|AdaBoost|91.674333|91.779023|91.597941|91.674333|
|Logistic Regression|91.674333|91.779023|91.597941|91.674333|
|Voting Classifier|95.262190|95.426846|95.178921|95.262190|

So, in both the cases, **SVM** gave the best results with the accuracy of _97.42%_ when the dataset was balanced.

Thus, for both the datasets, the accuracy is fairly 97% using SVM.

## IV. Results

### Model Evaluation and Validation

To finalize the model, various other models were also tested along and tweaked using _RandomSearchCV_, which searches the best combination of parameters for the model. The datasets are divided as training and test sets with 80%-20% partitions, where both the training and test sets are completely isolated from each other. Thus, in a way, the model is being trained on the train set and being tested on unseen data which is test set. Finally, the model's performance is evaluated with evaluation metrics such as accuracy score, F1-score, precision and recall.

After dataset being balanced, the models predicted better since they were not being biased by the more number of observations of a single class. Thus the accuracy of the final model, which is SVM for both the datasets increased by about 35%.

### Justification

In the benchmark model, the red wine dataset gave 73.43% accuracy with Random Forest with PCA and 67.45% accuracy with the same model, whereas the results got by me had SVM giving the accuracy score as approx. 97% for both datasets.

Following are the results got from different algorithms:

[Red wine evaluation metric](/Images/fig.3.1.2.png)
[White wine evaluation metric](/Images/fig.3.1.3.png)

## V. Conclusion

### Free-Form Visualization

One of te most important quality is the free SO2 which plays a major role in deciding the quality of wines, taking the pH of the wines too. Thus, a mathematical model was created using the existing data points using the formulation as follows:

For red wines, optimal pH range id 3.3-3.6, which implies the optimal free SO2 will be:
- Lower bound = [pH -3.0] * 100 = [3.3 - 3.0] * 100 = 30 mg/L
- Upper bound = [pH -3.0] * 100 = [3.6 - 3.0] * 100 = 60 mg/L

For white wines, optimal pH range id 3.3-3.6, which implies the optimal free SO2 will be:
- Lower bound = [pH -3.0] * 100 = [[3.0 - 3.0] * 100] + 10 = 10 mg/L
- Upper bound = [pH -3.0] * 100 = [[3.4 - 3.0] * 100] + 10 = 50 mg/L

Using these parameters a regression line was fitted as shown in the following figures:

[Red Wines - Calculation of Free SO2 given pH](/Images/fig.4.1.1.png)
[White Wines - Calculation of Free SO2 given pH](/Images/fig.4.1.2.png)

In the above figures, only those datapoints were considered which fell into the optimal range of both pH and free SO2.

### Reflection

Foolowing steps were employed in the problem solving:

1. **Feature Exploration** - To start with, each and every feature of the dataset was studied to understand the importance and role of the features in deciding the predictor variable. 
2. **Balancing the dataset** - Then, keeping the feature role in the wines production in mind, the correlation between all the features was found and then based in the correlation obtained the features were deeply studied how they are impacting the quality of the wine. Also, both the datasets were found highly skewed and thus the dataset was balanced using SMOTENN, an algorithm that over-samples the dataset using nearest neighbours.
3. **Data Exploration** - The important fetures which were thought to be the highest contributors towards quality predictors were explored further using plots, and a mathematical model was created using the most important feature, ie. free SO2 content.
4. **Algorithms and Techniques** - Various algorithms were used to predict the quality of wine. All of them were  tuned using RandomSearchCV, which optimized the algorithms' parameters to the best possible combination.
5. **Model Evaluation** - Models were evaluated against the evaluation metric such as accuracy score, F1-score, precision and recall.

According to me, this should be the general approach for solving such classification problems.

### Improvement

The one parameter which I believe would have helped even more would have been the _number of years_ the wines have aged. This would have been helped to analyse that if the wine is aged more than the others, then there is a high probalility that it might require free SO2 content check from time-to-time to see if we need to inject the same more to maintain its quantity to inhibit the microbes growth. Also, the recently aged wines, on the contrary, should not demand such needs and if they do so, then they are not carefully produced and thus belong to low quality buckets. The introduction of this parameter might be helpful in performance enhancement, but even in its absence the designed model worked just fine.
-----------
