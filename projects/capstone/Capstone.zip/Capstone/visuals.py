import numpy as np
import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from sklearn.grid_search import RandomizedSearchCV
from sklearn.ensemble import AdaBoostClassifier, RandomForestClassifier, VotingClassifier
from sklearn.linear_model import LogisticRegression

from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score


def set_aes(self, title, xlab, ylab):
    
    self.set_title(title, fontdict={'fontsize':14, 'fontweight':'bold'})
    self.set_xlabel(xlab, fontdict={'fontsize':12})
    self.set_ylabel(ylab, fontdict={'fontsize': 12})

def plot_heatmap(data):
    
    mask = np.zeros_like(data)
    mask[np.triu_indices_from(mask)] = True
    with sns.axes_style("white"):
        fig, ax = plt.subplots(figsize=(10,10)) 
        cmap = sns.diverging_palette(220, 10, as_cmap=True)
        sns.heatmap(data, mask=mask, annot=True, cmap=cmap, square=True, ax=ax)
        
    return fig, ax

def box_plot(data1, data2, x, y):
    
    plt.subplots(1, 2, figsize=(20, 8))
    q_order =['Worst', 'Average', 'Good', 'Best']
    
    plt.subplot(121)
    p1 = sns.boxplot(x=x, y=y, data=data1, order=q_order)
    plt.subplot(122)
    p2 = sns.boxplot(x=x, y=y, data=data2, order=q_order)
    
    return p1, p2

def evaluation_metric(y_pred, y_test):
    acc = accuracy_score(y_pred, y_test)
    f1 = f1_score(y_pred, y_test, average='weighted')
    precision = precision_score(y_test, y_pred, average='weighted')
    recall = recall_score(y_test, y_pred, average='weighted')
    
    return {'Accuracy': acc, 'F1-score':f1, 'Precision': precision, 'Recall': recall}

def models_prediction(data):
    
    pred_df = pd.DataFrame(columns=['Accuracy', 'F1-score', 'Precision', 'Recall'])
    
    X = data.loc[:, ~data.columns.isin(['quality bucket','quality'])]
    y = data.loc[:, 'quality']
    
    # Splitting train-test set
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=.2)
    
    ### Support Vector Machine
#     print('\nSVM')
    svc = SVC(random_state=1)
    svc_param = {'C':np.linspace(.01,40,5),  
                 'degree':np.arange(3, 8), 
                 'gamma':np.linspace(.01,1,5)}
    svc_rfc = RandomizedSearchCV(svc, svc_param)
    y_pred = svc_rfc.fit(X_train, y_train).predict(X_test)
    pred_df = pred_df.append(pd.DataFrame([evaluation_metric(y_pred, y_test)], index=['SVM']))
    
    ### Decision Tree
#     print('\nDecision Tree')
    dt = DecisionTreeClassifier(random_state=1)
    dt_param = {'criterion':['gini', 'entropy'], 
                'min_samples_leaf':np.arange(2,10)}
    dt_rfc = RandomizedSearchCV(dt, dt_param)
    y_pred = dt_rfc.fit(X_train, y_train).predict(X_test)
    pred_df = pred_df.append(pd.DataFrame([evaluation_metric(y_pred, y_test)], index=['Decision Tree']))
    
    ### Random Forest
#     print('\nRandom Forest')
    rf = RandomForestClassifier(random_state=1)
    rf_param = {'n_estimators':np.arange(2,20),
                'criterion':['gini', 'entropy']}
    rf_rfc = RandomizedSearchCV(rf, rf_param)
    y_pred = rf_rfc.fit(X_train, y_train).predict(X_test)
    pred_df = pred_df.append(pd.DataFrame([evaluation_metric(y_pred, y_test)], index=['Random Forest']))
    
    ### AdaBoost
#     print('\nAdaboost')
    ab = AdaBoostClassifier(base_estimator=DecisionTreeClassifier(random_state=1), random_state=1)
    ab_param = {'n_estimators':np.arange(2,20),
               'learning_rate':[.001, .01,.1]}
    ab_rfc = RandomizedSearchCV(ab, ab_param)
    y_pred = ab_rfc.fit(X_train, y_train).predict(X_test)
    pred_df = pred_df.append(pd.DataFrame([evaluation_metric(y_pred, y_test)], index=['AdaBoost']))
    
    ### Logistic Regression
#     print('\nLogistic Regression')
    lr = LogisticRegression(random_state=1)
    lr_param = {'penalty': ['l1', 'l2'],
                'C':np.linspace(.01,40,5)}
    lr_rfc = RandomizedSearchCV(ab, ab_param)
    y_pred = lr_rfc.fit(X_train, y_train).predict(X_test)
    pred_df = pred_df.append(pd.DataFrame([evaluation_metric(y_pred, y_test)], index=['Logistic Regression']))
    
    ### Voting Classifier
    vc = VotingClassifier(estimators=[('svc', svc_rfc), ('dt', dt_rfc), ('rf', rf_rfc), ('ab', ab_rfc), ('lr', lr_rfc)],
                          voting='hard')
    y_pred = vc.fit(X_train, y_train).predict(X_test)
    pred_df = pred_df.append(pd.DataFrame([evaluation_metric(y_pred, y_test)], index=['Voting Classifier']))
    return pred_df